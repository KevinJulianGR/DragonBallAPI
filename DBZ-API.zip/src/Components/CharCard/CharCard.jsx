import React from 'react';
import './CharCard.css';  
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import CardActionArea from '@mui/material/CardActionArea';

const CharCard = (props) => {
  return (
    <Card sx={{ 
      maxWidth: 345, 
      backgroundColor: '#2c3e50',  
      color: '#ecf0f1', 
      borderRadius: '10px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      transition: 'transform 0.3s, box-shadow 0.3s',
      '&:hover': {
        transform: 'translateY(-5px)',
        boxShadow: '0 10px 15px rgba(0, 0, 0, 0.4)',
      }
    }}>
      <CardActionArea>
        <CardMedia
          component="img"
          image={props.img}
          alt="Character"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            {props.nombre}
          </Typography>
          <Typography variant="body2" sx={{ color: '#bdc3c7' }}>
            {props.especie}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}

CharCard.defaultProps = {
  img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8GAcNf2A8wsr7rHBPhxfvi36V6Aq2kswNUg&s",
  nombre: "_____",
  especie: "____"
};

export default CharCard;
